package com.example.ashleyhwang.pp4;

public class News {
    private String title;
    private String desc;
    private String url;

    public void setTitle(String title) {
        this.title = title;
    }
    public String getTitle() {
        return title;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public String getDesc() { return desc; }
    public void setUrl(String url) { this.url = url; }
    public String getUrl() { return url; }

}
